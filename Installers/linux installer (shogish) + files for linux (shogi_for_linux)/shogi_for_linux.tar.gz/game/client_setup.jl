include("database.jl")
include("net_user_request_seed.jl")
include("net_user_move.jl")

#TEST
# gamename = "test"
# ip = "207.23.205.29"
# port = 2004
# variant = "Standard Shogi"
# first_player = "human"
# time_limit = 300
# time_increment = 0
# initial_option = "Start a new game"
##
#----------------------------------------------------------------------------------------

