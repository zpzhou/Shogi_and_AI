HOW TO PLAY

1. Run the Julia installer by running the following commands in the terminal:

	sudo add-apt-repository ppa:staticfloat/juliareleases
	sudo add-apt-repository ppa:staticfloat/julia-deps
	sudo apt-get update
	sudo apt-get install julia


2. Run Julia either by double-clicking the Julia executable or running julia from the command line.

3. Change directory into “game” folder.

4. Type include("game.jl") in the interactive session and press enter. A window for the game will appear.

5. In the toolbar, select File -> Start a new game.

6. Enjoy the game!